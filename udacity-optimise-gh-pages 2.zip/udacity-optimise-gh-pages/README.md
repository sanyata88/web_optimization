# Installation #
* Clone or download zip file to your desktop from : https://github.com/sanyata88/web_optimization
* open index.html in your browser to run website
* Open the files in a text editor and look for optimization changes mentioned below.

# Steps for Optimization #
* Minify and inline CSS for faster page rendering
* Change JS loading to async
* Compress images

# Alterations in JavaScript and CSS #
## Change Pizza Size ##
Changed the image size of pizza to make it load faster using the resize() function.
200 pizzas cannot be displayed on the screen. Only a certain number can be displayed depending on screen width and height.
Instead of the for loop in the updatePositions() function, replace it to generate only the required number of pizzas.
Use 'transform: translateX' instead of 'style.left'.
Changed the querySelectorAll() with getElementByID or getElementsByClass.
Used the Hack from David Walsh to force each pizza div onto it's own layer. This speeds up paint time.
Ref : http://davidwalsh.name/translate3d
Altered this part of code :
//transform: translatex(0);
backface-visibility: hidden;//
